package com.desafio.companyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
